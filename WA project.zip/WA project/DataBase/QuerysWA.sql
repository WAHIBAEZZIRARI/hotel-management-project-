create database HOTEL_EZZIRARY;
create table Client(
    email varchar(45) primary key,
    first_name varchar(45) not null ,
    last_name varchar(45) not null,
    password varchar(45) not null 
);

create table Reservation(
    id_reservation INT PRIMARY KEY AUTO_INCREMENT,
    date_reservation date ,
    room varchar(45) not null,
    meal varchar(45),
    entertaiment varchar(45),
    cost decimal(10,2)
);

create table admin(
    id_admin int primary key ,
    nom varchar(45) ,
    password varchar(45)
);

create table admin(
    id_admin int primary key ,
    nom varchar(45) ,
    password varchar(45)
);

CREATE TABLE IF NOT EXISTS user_selections (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre_de_nuit INT,
    room VARCHAR(255),
    meal VARCHAR(255),
    activity VARCHAR(255),
    booking_date DATE
);
ALTER TABLE user_selections ADD COLUMN total_price DECIMAL(10, 2);
