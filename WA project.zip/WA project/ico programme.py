from PIL import Image

def png_to_ico(input_path, output_path):
    png_image = Image.open(input_path)
    png_image.save(output_path, format="ico")

if __name__ == "__main__":
    input_png_path = "hotel.png"
    output_ico_path = "hotel.ico"
    png_to_ico(input_png_path, output_ico_path)
