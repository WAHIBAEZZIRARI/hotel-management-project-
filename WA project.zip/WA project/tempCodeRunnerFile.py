def switch_page2(self):
            root.withdraw()  # Hide the current window
            subprocess.run(["python", "sign-up.py"])