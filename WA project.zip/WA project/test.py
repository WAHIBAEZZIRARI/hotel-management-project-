from tkinter import Tk, Entry
import mysql.connector 
import subprocess

root = Tk()
root.geometry("300x200")

# Create an entry with a black border
entry = Entry(root, bd=2, relief="solid", highlightbackground="green", highlightthickness=2)
entry.pack(pady=20)

root.mainloop()
import tkinter as tk

class HotelClientInfoApp:
    def __init__(self, master):
        self.master = master
        self.master.title("Hotel Client Information")
        
        self.client_info_label = tk.Label(master, text="Client Information", font=("Helvetica", 16))
        self.client_info_label.pack(pady=10)
        
        self.name_label = tk.Label(master, text="Name:")
        self.name_label.pack()
        
        self.name_entry = tk.Entry(master)
        self.name_entry.pack()
        
        self.email_label = tk.Label(master, text="Email:")
        self.email_label.pack()
        
        self.email_entry = tk.Entry(master)
        self.email_entry.pack()
        
        self.phone_label = tk.Label(master, text="Phone:")
        self.phone_label.pack()
        
        self.phone_entry = tk.Entry(master)
        self.phone_entry.pack()
        
        self.address_label = tk.Label(master, text="Address:")
        self.address_label.pack()
        
        self.address_entry = tk.Entry(master)
        self.address_entry.pack()
        
        self.submit_button = tk.Button(master, text="Submit", command=self.submit_info)
        self.submit_button.pack(pady=20)
        
    def submit_info(self):
        name = self.name_entry.get()
        email = self.email_entry.get()
        phone = self.phone_entry.get()
        address = self.address_entry.get()
        
        # You can add code here to process or store the client information
        
        # For now, just print the information
        print("Name:", name)
        print("Email:", email)
        print("Phone:", phone)
        print("Address:", address)

def main():
    root = tk.Tk()
    app = HotelClientInfoApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
